package com.example.nspextract

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.Settings
import android.widget.*
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var logView: TextView
    private lateinit var progText: TextView
    private lateinit var bar: ProgressBar
    private lateinit var scroll: ScrollView
    private lateinit var destBtn: Button
    private lateinit var updBtn: Button
    private val allBtns = mutableListOf<Button>()
    private var nspPath: String? = null
    private var updPath: String? = null
    private var destPath: String =
        File(Environment.getExternalStorageDirectory(), "AllGenURecomp/data").path
    @Volatile private var busy = false

    private val REQ_KEYS = 1
    private val REQ_NSP = 2
    private val REQ_DEST = 3
    private val REQ_UPD = 4

    private class Job(
        val keys: File,
        val work: File,
        val deleted: AtomicLong,
        val phase: AtomicReference<String>
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24) }
        fun btn(text: String, onClick: () -> Unit): Button = Button(this).apply {
            this.text = text; setOnClickListener { onClick() }; root.addView(this); allBtns.add(this)
        }
        btn("1. Pilih prod.keys") { pick(REQ_KEYS) }
        btn("2. Pilih NSP game (base)") { pick(REQ_NSP) }
        updBtn = btn("Pilih NSP update (opsional)\nbelum dipilih") { pick(REQ_UPD) }
        btn("Hapus pilihan update") {
            if (!busy) { updPath = null; updBtn.text = "Pilih NSP update (opsional)\nbelum dipilih"; say("Update tidak dipakai.") }
        }
        destBtn = btn("3. Folder tujuan:\n$destPath") { pickFolder() }
        btn("Ekstrak ExeFS") { startExtract(true, false) }
        btn("Ekstrak RomFS") { startExtract(false, true) }
        btn("Ekstrak ExeFS + RomFS") { startExtract(true, true) }

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000 }
        root.addView(bar, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 16 })
        progText = TextView(this).apply { textSize = 14f; setPadding(0, 8, 0, 16); text = "Belum berjalan." }
        root.addView(progText)

        logView = TextView(this).apply { textSize = 12f; setTextIsSelectable(true) }
        scroll = ScrollView(this).apply { addView(logView) }
        val sv = ScrollView(this).apply { addView(root) }
        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        outer.addView(sv, LinearLayout.LayoutParams(-1, 0, 3f))
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 2f))
        setContentView(outer)

        if (!Environment.isExternalStorageManager()) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            )
            say("Aktifkan 'Akses semua file' lalu buka ulang aplikasi.")
        }
        if (File(filesDir, "prod.keys").exists()) say("prod.keys sudah tersimpan.")
    }

    private fun pick(req: Int) {
        if (busy) return
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
        startActivityForResult(i, req)
    }

    private fun pickFolder() {
        if (busy) return
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_DEST)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data ?: return
        if (resultCode != RESULT_OK) return
        when (requestCode) {
            REQ_KEYS -> {
                contentResolver.openInputStream(uri)?.use { inp ->
                    File(filesDir, "prod.keys").outputStream().use { inp.copyTo(it) }
                }
                say("prod.keys disimpan.")
            }
            REQ_NSP -> {
                nspPath = uriToPath(uri)
                say(nspPath?.let { "NSP base: $it" }
                    ?: "Tidak bisa ambil path. Pilih file dari 'Penyimpanan internal' / SD card, bukan dari Recent/Downloads.")
            }
            REQ_UPD -> {
                updPath = uriToPath(uri)
                if (updPath == null) say("Tidak bisa ambil path update. Pilih dari 'Penyimpanan internal' / SD card.")
                else { updBtn.text = "NSP update:\n${File(updPath!!).name}"; say("NSP update: $updPath") }
            }
            REQ_DEST -> {
                val p = treeToPath(uri)
                if (p == null) say("Folder tidak bisa dibaca. Pilih folder di penyimpanan internal / SD card.")
                else { destPath = p; destBtn.text = "3. Folder tujuan:\n$p"; say("Tujuan: $p") }
            }
        }
    }

    private fun idToPath(id: String): String? {
        if (id.startsWith("raw:")) return id.removePrefix("raw:")
        val parts = id.split(":", limit = 2)
        if (parts.size != 2) return null
        val base = if (parts[0] == "primary") "/storage/emulated/0" else "/storage/${parts[0]}"
        return if (parts[1].isEmpty()) base else "$base/${parts[1]}"
    }

    private fun uriToPath(uri: Uri): String? =
        try { idToPath(DocumentsContract.getDocumentId(uri)) } catch (e: Exception) { null }

    private fun treeToPath(uri: Uri): String? =
        try { idToPath(DocumentsContract.getTreeDocumentId(uri)) } catch (e: Exception) { null }

    // Ambil encrypted title key dari .tik (untuk NCA dengan rights ID)
    private fun readTitleKey(dir: File): String? {
        val tik = dir.listFiles { f -> f.name.endsWith(".tik") }?.firstOrNull() ?: return null
        val b = tik.readBytes()
        if (b.size < 0x200) return null
        val sig = (b[0].toInt() and 0xFF) or ((b[1].toInt() and 0xFF) shl 8) or
                ((b[2].toInt() and 0xFF) shl 16) or ((b[3].toInt() and 0xFF) shl 24)
        val dataOff = when (sig) {
            0x10000, 0x10003 -> 0x240
            0x10001, 0x10004 -> 0x140
            0x10002, 0x10005 -> 0x80
            else -> return null
        }
        return b.copyOfRange(dataOff + 0x40, dataOff + 0x50).joinToString("") { "%02x".format(it) }
    }

    private fun fmtBytes(b: Long): String =
        if (b >= (1L shl 30)) "%.2f GB".format(b / 1073741824.0) else "%d MB".format(b / 1048576)

    private fun fmtTime(sec: Long): String {
        val m = sec / 60; val s = sec % 60
        return if (m > 0) "$m mnt $s dtk" else "$s dtk"
    }

    private fun setBusyUi(b: Boolean) = runOnUiThread {
        allBtns.forEach { it.isEnabled = !b }
        window.decorView.keepScreenOn = b
    }

    private fun setProgress(pct: Double, text: String) = runOnUiThread {
        bar.progress = (pct * 10).toInt()
        progText.text = text
    }

    private val important = Regex("(rror|ailed|nvalid|issing|exit)", RegexOption.IGNORE_CASE)
    private fun brief(o: String) =
        o.lines().filter { !it.contains("[WARN]") && important.containsMatchIn(it) }.joinToString("\n")

    // NCA Program = NCA terbesar (bukan .cnmt.nca)
    private fun largestNca(dir: File): File? =
        dir.listFiles { f -> f.name.endsWith(".nca") && !f.name.endsWith(".cnmt.nca") }
            ?.maxByOrNull { it.length() }

    private fun delTracked(f: File, job: Job) {
        val n = if (f.isDirectory) f.walkTopDown().filter { it.isFile }.sumOf { it.length() } else f.length()
        job.deleted.addAndGet(n)
        f.deleteRecursively()
    }

    private fun startMonitor(job: Job, total: Long, running: AtomicBoolean) {
        thread {
            var last = 0L
            var lastT = System.currentTimeMillis()
            var ema = 0.0
            var maxPct = 0.0
            while (running.get()) {
                val cur = job.work.walkTopDown().filter { it.isFile }.sumOf { it.length() } + job.deleted.get()
                val now = System.currentTimeMillis()
                val dt = (now - lastT) / 1000.0
                if (dt > 0) {
                    val inst = (cur - last) / dt
                    ema = if (ema == 0.0) inst else ema * 0.8 + inst * 0.2
                }
                last = cur; lastT = now
                val pct = maxOf(maxPct, (cur * 100.0 / total).coerceAtMost(99.0))
                maxPct = pct
                val eta = if (ema > 1.0) ((total - cur) / ema).toLong().coerceAtLeast(0) else -1L
                val etaTxt = if (eta >= 0) "sisa ~${fmtTime(eta)}" else "menghitung..."
                val speedTxt = "%.0f MB/s".format(ema / 1048576.0)
                setProgress(
                    pct,
                    "%.1f%% • %s\n%s • %s • %s ditulis".format(pct, etaTxt, job.phase.get(), speedTxt, fmtBytes(cur))
                )
                Thread.sleep(1000)
            }
        }
    }

    // Mode biasa: hanya NSP base
    private fun runBase(job: Job, nsp: String, doExe: Boolean, doRom: Boolean): Pair<File?, File?> {
        val keys = job.keys.path
        val nspDir = File(job.work, "nsp").apply { mkdirs() }
        say("Membuka NSP (bisa lama, tunggu)...")
        say(brief(Hactool.exec("-t", "pfs0", "-k", keys, "--pfs0dir=${nspDir.path}", nsp)))

        val tk = readTitleKey(nspDir)
        val ncas = nspDir.listFiles { f -> f.name.endsWith(".nca") }?.sortedBy { it.name } ?: emptyList()
        say("${ncas.size} file NCA. Mencari NCA program...")

        var bestExe: File? = null
        var bestRom: File? = null
        var bestScore = -1L

        for ((idx, nca) in ncas.withIndex()) {
            job.phase.set("Mengekstrak NCA ${idx + 1}/${ncas.size}")
            val d = File(job.work, nca.name.removeSuffix(".nca")).apply { mkdirs() }
            val args = mutableListOf("-t", "nca", "-k", keys)
            if (tk != null) args += "--titlekey=$tk"
            if (doExe) args += "--exefsdir=${d.path}/exefs"
            if (doRom) args += "--romfsdir=${d.path}/romfs"
            args += nca.path
            say("Memeriksa ${nca.name}")
            say(brief(Hactool.exec(*args.toTypedArray())))

            val exe = File(d, "exefs")
            val rom = File(d, "romfs")
            val hasMain = File(exe, "main").exists()
            val romSize = if (rom.isDirectory) rom.walkTopDown().filter { it.isFile }.sumOf { it.length() } else 0L
            val score = (if (hasMain) 1L shl 50 else 0L) + romSize
            if ((hasMain || romSize > 0) && score > bestScore) {
                bestScore = score
                bestExe = if (hasMain) exe else null
                bestRom = if (romSize > 0) rom else null
            }
            job.deleted.addAndGet(nca.length())
            nca.delete()
        }
        return Pair(bestExe, bestRom)
    }

    // Mode gabung update: exefs dari update, romfs = base + update
    private fun runMerge(job: Job, nsp: String?, upd: String, doExe: Boolean, doRom: Boolean): Pair<File?, File?> {
        val keys = job.keys.path

        job.phase.set("Membuka NSP update...")
        say("Membuka NSP update...")
        val updDir = File(job.work, "upd").apply { mkdirs() }
        say(brief(Hactool.exec("-t", "pfs0", "-k", keys, "--pfs0dir=${updDir.path}", upd)))
        val updTk = readTitleKey(updDir)
        val updNca = largestNca(updDir)
        if (updNca == null) { say("Gagal: NCA program di NSP update tidak ditemukan."); return Pair(null, null) }
        say("NCA update: ${updNca.name}")

        var basePlain: File? = null
        if (doRom) {
            if (nsp == null) { say("Pilih NSP base dulu."); return Pair(null, null) }
            job.phase.set("Membuka NSP base...")
            say("Membuka NSP base (bisa lama)...")
            val baseDir = File(job.work, "base").apply { mkdirs() }
            say(brief(Hactool.exec("-t", "pfs0", "-k", keys, "--pfs0dir=${baseDir.path}", nsp)))
            val baseTk = readTitleKey(baseDir)
            val baseNca = largestNca(baseDir)
            if (baseNca == null) { say("Gagal: NCA program di NSP base tidak ditemukan."); return Pair(null, null) }

            job.phase.set("Mendekripsi NCA base...")
            say("Mendekripsi NCA base ${baseNca.name} (lama)...")
            val plain = File(job.work, "base_plain.nca")
            val a = mutableListOf("-t", "nca", "-k", keys)
            if (baseTk != null) a += "--titlekey=$baseTk"
            a += listOf("--plaintext=${plain.path}", baseNca.path)
            say(brief(Hactool.exec(*a.toTypedArray())))
            delTracked(baseDir, job)
            if (!plain.exists() || plain.length() == 0L) {
                say("Gagal membuat NCA base terdekripsi. Cek prod.keys atau ticket NSP base.")
                return Pair(null, null)
            }
            basePlain = plain
        }

        job.phase.set("Menggabungkan update...")
        say("Menggabungkan update...")
        val out = File(job.work, "merged").apply { mkdirs() }
        val a = mutableListOf("-t", "nca", "-k", keys)
        if (updTk != null) a += "--titlekey=$updTk"
        if (basePlain != null) a += "--basenca=${basePlain.path}"
        if (doExe) a += "--exefsdir=${out.path}/exefs"
        if (doRom) a += "--romfsdir=${out.path}/romfs"
        a += updNca.path
        say(brief(Hactool.exec(*a.toTypedArray())))
        basePlain?.let { delTracked(it, job) }

        val exe = File(out, "exefs")
        val rom = File(out, "romfs")
        return Pair(
            if (File(exe, "main").exists()) exe else null,
            if (rom.isDirectory && !rom.list().isNullOrEmpty()) rom else null
        )
    }

    private fun startExtract(doExe: Boolean, doRom: Boolean) {
        if (busy) return say("Masih berjalan, tunggu selesai.")
        val keys = File(filesDir, "prod.keys")
        if (!keys.exists()) return say("Pilih prod.keys dulu.")
        val updFile = updPath?.let { File(it) }
        val needBase = updFile == null || doRom
        val nsp = nspPath
        if (needBase && nsp == null) return say("Pilih NSP game (base) dulu.")

        val dest = File(destPath)
        val finalExe = File(dest, "exefs")
        val finalRom = File(dest, "romfs")

        // Pengaman: NSP tidak boleh berada di folder yang akan dikosongkan
        fun inside(f: File, parent: File) =
            f.canonicalPath.startsWith(parent.canonicalPath + File.separator)
        val sources = listOfNotNull(if (needBase) nsp?.let { File(it) } else null, updFile)
        for (s in sources) {
            if ((doExe && inside(s, finalExe)) || (doRom && inside(s, finalRom))) {
                return say("Batal: ${s.name} ada di dalam folder exefs/romfs tujuan dan akan terhapus. Pindahkan ke folder lain dulu.")
            }
        }

        busy = true
        setBusyUi(true)
        val running = AtomicBoolean(true)
        val startTime = System.currentTimeMillis()
        val baseSize = (if (needBase) nsp?.let { File(it).length() } else 0L)?.coerceAtLeast(1L) ?: 1L
        val updSize = updFile?.length() ?: 0L
        val total = when {
            updFile == null -> baseSize * (if (doRom) 2L else 1L)
            doRom -> baseSize * 3L + updSize          // salin base + base terdekripsi + romfs + update
            else -> updSize.coerceAtLeast(1L)
        }
        val job = Job(keys, File(dest, "_work"), AtomicLong(0), AtomicReference("Memulai..."))

        thread {
            try {
                dest.mkdirs()
                job.work.deleteRecursively(); job.work.mkdirs()
                startMonitor(job, total, running)
                if (updFile != null && doRom) say("Mode gabung update. Siapkan ruang kosong ±30 GB.")

                val (bestExe, bestRom) =
                    if (updFile == null) runBase(job, nsp!!, doExe, doRom)
                    else runMerge(job, nsp, updFile.path, doExe, doRom)

                job.phase.set("Memindahkan hasil...")
                fun move(src: File?, dst: File) {
                    if (src == null) return
                    dst.deleteRecursively()
                    if (!src.renameTo(dst)) { src.copyRecursively(dst, true); src.deleteRecursively() }
                }
                if (doExe) move(bestExe, finalExe)
                if (doRom) move(bestRom, finalRom)
                job.work.deleteRecursively()

                val okExe = !doExe || finalExe.exists()
                val okRom = !doRom || finalRom.exists()
                running.set(false)
                val took = (System.currentTimeMillis() - startTime) / 1000
                if (okExe && okRom) {
                    setProgress(100.0, "100% • Selesai dalam ${fmtTime(took)}")
                    say(if (updFile != null) "Selesai (update digabung)." else "Selesai.")
                    if (doExe) say("exefs: ${finalExe.path}")
                    if (doRom) say("romfs: ${finalRom.path}")
                } else {
                    setProgress(0.0, "Gagal.")
                    say("Gagal: hasil tidak ditemukan. Kemungkinan prod.keys tidak cocok atau NSP butuh ticket.")
                }
            } catch (e: Exception) {
                setProgress(0.0, "Error.")
                say("Error: ${e.message}")
            } finally {
                running.set(false)
                busy = false
                setBusyUi(false)
            }
        }
    }

    private fun say(s: String) = runOnUiThread {
        logView.append(s + "\n"); scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }
}
