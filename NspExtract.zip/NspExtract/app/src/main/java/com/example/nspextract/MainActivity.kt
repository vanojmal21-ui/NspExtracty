package com.example.nspextract

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.Settings
import android.widget.*
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var logView: TextView
    private lateinit var status: TextView
    private lateinit var scroll: ScrollView
    private lateinit var destBtn: Button
    private var nspPath: String? = null
    private var destPath: String =
        File(Environment.getExternalStorageDirectory(), "AllGenURecomp/data").path
    @Volatile private var busy = false

    private val REQ_KEYS = 1
    private val REQ_NSP = 2
    private val REQ_DEST = 3

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24) }
        fun btn(text: String, onClick: () -> Unit): Button = Button(this).apply {
            this.text = text; setOnClickListener { onClick() }; root.addView(this)
        }
        btn("1. Pilih prod.keys") { pick(REQ_KEYS) }
        btn("2. Pilih file NSP") { pick(REQ_NSP) }
        destBtn = btn("3. Folder tujuan:\n$destPath") { pickFolder() }
        btn("Ekstrak ExeFS") { startExtract(true, false) }
        btn("Ekstrak RomFS") { startExtract(false, true) }
        btn("Ekstrak ExeFS + RomFS") { startExtract(true, true) }
        status = TextView(this).apply { textSize = 14f; setPadding(0, 16, 0, 16) }
        root.addView(status)
        logView = TextView(this).apply { textSize = 12f; setTextIsSelectable(true) }
        scroll = ScrollView(this).apply { addView(logView) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        if (!Environment.isExternalStorageManager()) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            )
            say("Aktifkan 'Akses semua file' lalu buka ulang aplikasi.")
        }
        if (File(filesDir, "prod.keys").exists()) say("prod.keys sudah tersimpan.")
    }

    private fun pick(req: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
        startActivityForResult(i, req)
    }

    private fun pickFolder() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_DEST)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data ?: return
        if (resultCode != RESULT_OK) return
        when (requestCode) {
            REQ_KEYS -> {
                contentResolver.openInputStream(uri)?.use { inp ->
                    File(filesDir, "prod.keys").outputStream().use { inp.copyTo(it) }
                }
                say("prod.keys disimpan.")
            }
            REQ_NSP -> {
                nspPath = uriToPath(uri)
                say(nspPath?.let { "NSP: $it" }
                    ?: "Tidak bisa ambil path. Pilih file dari 'Penyimpanan internal' / SD card, bukan dari Recent/Downloads.")
            }
            REQ_DEST -> {
                val p = treeToPath(uri)
                if (p == null) say("Folder tidak bisa dibaca. Pilih folder di penyimpanan internal / SD card.")
                else { destPath = p; destBtn.text = "3. Folder tujuan:\n$p"; say("Tujuan: $p") }
            }
        }
    }

    private fun idToPath(id: String): String? {
        if (id.startsWith("raw:")) return id.removePrefix("raw:")
        val parts = id.split(":", limit = 2)
        if (parts.size != 2) return null
        val base = if (parts[0] == "primary") "/storage/emulated/0" else "/storage/${parts[0]}"
        return if (parts[1].isEmpty()) base else "$base/${parts[1]}"
    }

    private fun uriToPath(uri: Uri): String? =
        try { idToPath(DocumentsContract.getDocumentId(uri)) } catch (e: Exception) { null }

    private fun treeToPath(uri: Uri): String? =
        try { idToPath(DocumentsContract.getTreeDocumentId(uri)) } catch (e: Exception) { null }

    // Ambil encrypted title key dari .tik (untuk NCA dengan rights ID)
    private fun readTitleKey(dir: File): String? {
        val tik = dir.listFiles { f -> f.name.endsWith(".tik") }?.firstOrNull() ?: return null
        val b = tik.readBytes()
        if (b.size < 0x200) return null
        val sig = (b[0].toInt() and 0xFF) or ((b[1].toInt() and 0xFF) shl 8) or
                ((b[2].toInt() and 0xFF) shl 16) or ((b[3].toInt() and 0xFF) shl 24)
        val dataOff = when (sig) {
            0x10000, 0x10003 -> 0x240
            0x10001, 0x10004 -> 0x140
            0x10002, 0x10005 -> 0x80
            else -> return null
        }
        return b.copyOfRange(dataOff + 0x40, dataOff + 0x50).joinToString("") { "%02x".format(it) }
    }

    private fun startExtract(doExe: Boolean, doRom: Boolean) {
        if (busy) return say("Masih berjalan, tunggu selesai.")
        val nsp = nspPath ?: return say("Pilih NSP dulu.")
        val keys = File(filesDir, "prod.keys")
        if (!keys.exists()) return say("Pilih prod.keys dulu.")
        busy = true
        val running = AtomicBoolean(true)
        thread {
            try {
                val name = File(nsp).nameWithoutExtension
                val out = File(Environment.getExternalStorageDirectory(), "NSPExtract/$name")
                val work = File(out, "_work")
                work.deleteRecursively(); work.mkdirs()
                val nspDir = File(work, "nsp").apply { mkdirs() }

                thread {
                    while (running.get()) {
                        val mb = work.walkTopDown().filter { it.isFile }.sumOf { it.length() } / 1048576
                        setStatus("Sedang berjalan... $mb MB sudah ditulis")
                        Thread.sleep(3000)
                    }
                }

                val important = Regex("(rror|ailed|nvalid|issing|exit)", RegexOption.IGNORE_CASE)
                fun brief(o: String) =
                    o.lines().filter { !it.contains("[WARN]") && important.containsMatchIn(it) }.joinToString("\n")

                say("Membuka NSP (bisa lama, tunggu)...")
                say(brief(Hactool.exec("-t", "pfs0", "-k", keys.path, "--pfs0dir=${nspDir.path}", nsp)))

                val tk = readTitleKey(nspDir)
                val ncas = nspDir.listFiles { f -> f.name.endsWith(".nca") }?.sortedBy { it.name } ?: emptyList()
                say("${ncas.size} file NCA. Mencari NCA program...")

                var bestExe: File? = null
                var bestRom: File? = null
                var bestScore = -1L

                for (nca in ncas) {
                    val d = File(work, nca.name.removeSuffix(".nca")).apply { mkdirs() }
                    val args = mutableListOf("-t", "nca", "-k", keys.path)
                    if (tk != null) args += "--titlekey=$tk"
                    if (doExe) args += "--exefsdir=${d.path}/exefs"
                    if (doRom) args += "--romfsdir=${d.path}/romfs"
                    args += nca.path
                    say("Memeriksa ${nca.name}")
                    say(brief(Hactool.exec(*args.toTypedArray())))

                    val exe = File(d, "exefs")
                    val rom = File(d, "romfs")
                    val hasMain = File(exe, "main").exists()
                    val romSize = if (rom.isDirectory) rom.walkTopDown().filter { it.isFile }.sumOf { it.length() } else 0L
                    val score = (if (hasMain) 1L shl 50 else 0L) + romSize
                    if ((hasMain || romSize > 0) && score > bestScore) {
                        bestScore = score
                        bestExe = if (hasMain) exe else null
                        bestRom = if (romSize > 0) rom else null
                    }
                    nca.delete()
                }

                val dest = File(destPath).apply { mkdirs() }
                val finalExe = File(dest, "exefs")
                val finalRom = File(dest, "romfs")
                fun move(src: File?, dst: File) {
                    if (src == null) return
                    dst.deleteRecursively()
                    if (!src.renameTo(dst)) { src.copyRecursively(dst, true); src.deleteRecursively() }
                }
                if (doExe) move(bestExe, finalExe)
                if (doRom) move(bestRom, finalRom)
                work.deleteRecursively()
                out.delete()

                val okExe = !doExe || finalExe.exists()
                val okRom = !doRom || finalRom.exists()
                if (okExe && okRom) {
                    say("Selesai.")
                    if (doExe) say("exefs: ${finalExe.path}")
                    if (doRom) say("romfs: ${finalRom.path}")
                } else {
                    say("Gagal: hasil tidak ditemukan. Kemungkinan prod.keys tidak cocok atau NSP butuh ticket.")
                }
            } catch (e: Exception) {
                say("Error: ${e.message}")
            } finally {
                running.set(false)
                setStatus("")
                busy = false
            }
        }
    }

    private fun setStatus(t: String) = runOnUiThread { status.text = t }

    private fun say(s: String) = runOnUiThread {
        logView.append(s + "\n"); scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }
}
