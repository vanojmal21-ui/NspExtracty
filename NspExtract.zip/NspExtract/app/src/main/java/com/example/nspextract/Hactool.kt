package com.example.nspextract

object Hactool {
    init { System.loadLibrary("hactoolbridge") }

    @JvmStatic
    private external fun run(args: Array<String>): String

    fun exec(vararg args: String): String = run(arrayOf("hactool") + args)
}
