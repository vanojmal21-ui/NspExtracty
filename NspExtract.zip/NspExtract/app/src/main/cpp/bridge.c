#include <jni.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

extern int hactool_main(int argc, char **argv);

#define MAX_OUT (256 * 1024)

/* Jalankan hactool di proses anak (fork), karena hactool sering memanggil exit().
   stdout+stderr ditangkap lewat pipe. */
JNIEXPORT jstring JNICALL
Java_com_example_nspextract_Hactool_run(JNIEnv *env, jclass cls, jobjectArray jargs) {
    int argc = (*env)->GetArrayLength(env, jargs);
    char **argv = calloc(argc + 1, sizeof(char *));
    for (int i = 0; i < argc; i++) {
        jstring s = (jstring)(*env)->GetObjectArrayElement(env, jargs, i);
        const char *c = (*env)->GetStringUTFChars(env, s, NULL);
        argv[i] = strdup(c);
        (*env)->ReleaseStringUTFChars(env, s, c);
    }

    int fd[2];
    if (pipe(fd) != 0) return (*env)->NewStringUTF(env, "pipe() gagal");

    pid_t pid = fork();
    if (pid == 0) {
        close(fd[0]);
        dup2(fd[1], 1);
        dup2(fd[1], 2);
        close(fd[1]);
        setvbuf(stdout, NULL, _IONBF, 0);
        int rc = hactool_main(argc, argv);
        fflush(NULL);
        _exit(rc);
    }
    close(fd[1]);

    char *buf = malloc(MAX_OUT + 64);
    size_t len = 0;
    char tmp[4096];
    ssize_t n;
    while ((n = read(fd[0], tmp, sizeof(tmp))) > 0) {
        if (len + n <= MAX_OUT) { memcpy(buf + len, tmp, n); len += n; }
    }
    close(fd[0]);
    int status = 0;
    waitpid(pid, &status, 0);
    int code = WIFEXITED(status) ? WEXITSTATUS(status) : -1;
    len += snprintf(buf + len, 64, "\n[exit %d]\n", code);
    buf[len] = 0;

    for (int i = 0; i < argc; i++) free(argv[i]);
    free(argv);
    jstring out = (*env)->NewStringUTF(env, buf);
    free(buf);
    return out;
}
