# NSP Extract (hactool via NDK)

1. Taruh source hactool:
   git clone https://github.com/SciresM/hactool app/src/main/cpp/hactool
   (jika repo tidak membawa folder mbedtls, taruh mbedtls di app/src/main/cpp/mbedtls)
2. Buka folder ini di Android Studio, install NDK + CMake saat diminta, lalu Build > Build APK.
3. Di HP: beri "Akses semua file", pilih prod.keys, pilih NSP, tekan Ekstrak.
Hasil: /storage/emulated/0/NSPExtract/<nama>/<ncaid>/{exefs,romfs}
